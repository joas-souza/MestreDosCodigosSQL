CREATE TABLE Pessoa (
	Id INT IDENTITY(1,1),
	Nome VARCHAR(150) NOT NULL,
	RG VARCHAR(10) NOT NULL,
	CPF VARCHAR(14) NOT NULL,
	DataNascimento DATE NOT NULL,
	Sexo CHAR(1) NOT NULL,
	CONSTRAINT PK_Pessoa PRIMARY KEY (Id))
GO
CREATE NONCLUSTERED INDEX IX_Pessoa_CPF ON Pessoa (CPF)
CREATE NONCLUSTERED INDEX IX_Pessoa_RG ON Pessoa (RG)
GO

CREATE TABLE Credor (
	Id INT IDENTITY(1,1),
	PessoaId INT NOT NULL,
	CONSTRAINT PK_Credor PRIMARY KEY (Id), 
	CONSTRAINT FK_Credor_PessoaId FOREIGN KEY (PessoaId) REFERENCES Pessoa(Id))
GO
CREATE NONCLUSTERED INDEX IX_Credor_PessoaId ON Credor (PessoaId)
GO

CREATE TABLE Devedor (
	Id INT IDENTITY(1,1),
	PessoaId INT NOT NULL,
	CONSTRAINT PK_Devedor PRIMARY KEY (Id), 
	CONSTRAINT FK_Devedor_PessoaId FOREIGN KEY (PessoaId) REFERENCES Pessoa(Id))
GO
CREATE NONCLUSTERED INDEX IX_Devedor_PessoaId ON Devedor (PessoaId)
GO

CREATE TABLE Cidade (
	Id INT IDENTITY(1,1),
	Nome VARCHAR(100) NOT NULL,
	Estado CHAR(2) NOT NULL,
	CONSTRAINT PK_Cidade PRIMARY KEY (Id))
GO

CREATE TABLE Endereco (
	Id INT IDENTITY(1,1),
	Logradouro VARCHAR(150) NOT NULL,
	CidadeId INT NOT NULL,
	PessoaId INT NOT NULL,
	Numero INT NOT NULL,
	Cep VARCHAR(10) NOT NULL,
	Bairro VARCHAR(100) NOT NULL,
	CONSTRAINT PK_Endereco PRIMARY KEY (Id), 
	CONSTRAINT FK_Endereco_CidadeId FOREIGN KEY (CidadeId) REFERENCES Cidade(Id), 
	CONSTRAINT FK_Endereco_PessoaId FOREIGN KEY (PessoaId) REFERENCES Pessoa(Id))
GO
CREATE NONCLUSTERED INDEX IX_Endereco_CidadeId ON Endereco (CidadeId)
CREATE NONCLUSTERED INDEX IX_Endereco_PessoaId ON Endereco (PessoaId)
GO

CREATE TABLE Telefone (
	Id INT IDENTITY(1,1),
	DDD CHAR(3) NULL,
	PessoaId INT NOT NULL,
	Numero VARCHAR(15) NULL,
	CONSTRAINT PK_Telefone PRIMARY KEY (Id), 
    CONSTRAINT FK_Telefone_PessoaId FOREIGN KEY (PessoaId) REFERENCES Pessoa(Id))
GO
CREATE NONCLUSTERED INDEX IX_Telefone_PessoaId ON Telefone (PessoaId)
GO

CREATE TABLE Titulo (
	Id INT IDENTITY(1,1),
	NumeroContrato VARCHAR(20) NOT NULL,
	DevedorId INT NOT NULL,
	[Data] DATE NULL,
	CredorId INT NOT NULL,
	Valor DECIMAL(10,2) NOT NULL,
	CONSTRAINT PK_Titulo PRIMARY KEY (Id), 
	CONSTRAINT FK_Titulo_CredorId FOREIGN KEY (CredorId) REFERENCES Credor(Id),
	CONSTRAINT FK_Titulo_DevedorId FOREIGN KEY (DevedorId) REFERENCES Devedor(Id))
GO
CREATE NONCLUSTERED INDEX IX_Titulo_CredorId ON Titulo (CredorId)
CREATE NONCLUSTERED INDEX IX_Titulo_DevedorId ON Titulo (DevedorId)
GO

CREATE TABLE Parcelas (
	Id INT IDENTITY(1,1),
	Numero INT NOT NULL,
	TituloId INT NOT NULL,
	Valor DECIMAL(10,2) NOT NULL,
	Vencimento DATE NOT NULL,
	Complemento VARCHAR(20) NULL,
	Quitada BIT NOT NULL DEFAULT 0,
	ParcelaResidualId INT NULL,
	CONSTRAINT PK_Parcelas PRIMARY KEY (Id), 
	CONSTRAINT FK_Parcelas_TituloId FOREIGN KEY (TituloId) REFERENCES Titulo(Id),
	CONSTRAINT FK_Parcelas_ParcelaResidualId FOREIGN KEY (ParcelaResidualId) REFERENCES Parcelas(Id))
GO
CREATE NONCLUSTERED INDEX IX_Parcelas_TituloId ON Parcelas (TituloId)
GO

CREATE TABLE Historico (
       Id INT IDENTITY(1,1),
       Descricao VARCHAR(255) NOT NULL,
       [Data] DATETIME NOT NULL,
	   CONSTRAINT PK_Historico PRIMARY KEY (Id))
GO

CREATE TABLE HistoricoTitulo (
       HistoricoId INT NOT NULL,
       TituloId INT NOT NULL,
	   CONSTRAINT PK_HistoricoTitulo PRIMARY KEY (HistoricoId, TituloId), 
       CONSTRAINT FK_HistoricoTitulo_HistoricoId FOREIGN KEY (HistoricoId) REFERENCES Historico(Id), 
       CONSTRAINT FK_HistoricoTitulo_TituloId FOREIGN KEY (TituloId) REFERENCES Titulo(Id))
GO

CREATE TABLE Recebimento (
       Id INT IDENTITY(1,1),
       ValorTotal DECIMAL(10,2) NOT NULL,
       TituloId INT NOT NULL,
       DataPagamento DATETIME NOT NULL,
	   CONSTRAINT PK_Recebimento PRIMARY KEY (Id),
	   CONSTRAINT FK_Recebimento_TituloId FOREIGN KEY (TituloId) REFERENCES Titulo(Id))
GO
CREATE NONCLUSTERED INDEX IX_Recebimento_TituloId ON Recebimento (TituloId)
GO

CREATE TABLE RecebimentoParcelas (
       RecebimentoId INT NOT NULL,
       ParcelaId INT NOT NULL,
       ValorParcela DECIMAL(10,2) NOT NULL,
       VencimentoParcela DATE NOT NULL,
	   CONSTRAINT PK_RecebimentoParcelas PRIMARY KEY (RecebimentoId, ParcelaId), 
       CONSTRAINT FK_RecebimentoParcelas_RecebimentoId FOREIGN KEY (RecebimentoId) REFERENCES Recebimento(Id), 
       CONSTRAINT FK_RecebimentoParcelas_ParcelaId FOREIGN KEY (ParcelaId) REFERENCES Parcelas(Id))
GO

/*********************************Insers�o de dados*********************************/
--PESSOA
INSERT INTO Pessoa (Nome, RG, CPF, DataNascimento, Sexo) VALUES 
('Martinho da Vila', '142555574', '22257587841', '1985-01-01', 'M')
,('Zeca Pagodinho', '442555574', '12257587841', '1980-02-10', 'M')
,('Florentina de Jesus', '342555574', '32257587841', '1959-07-10', 'F')
,('Maria do Socorro', '242555574', '42257587841', '1990-01-01', 'F')
,('Albertino Credor', '842555574', '10257587841', '1975-01-01', 'M')
,('Joaquim Credor', '642555574', '11257587841', '1976-01-01', 'M')
,('Marco Antonio', '123555574', '99957587841', '1974-01-21', 'M')

INSERT INTO Devedor(PessoaId) VALUES (1),(2),(3),(4)

INSERT INTO Credor (PessoaId) VALUES (5),(6),(7)

INSERT INTO Cidade (Nome, Estado) VALUES
('Presidente Prudente', 'SP'),
('Presidente Epit�cio', 'SP'),
('Presidente Venceslau', 'SP'),
('S�o Paulo', 'SP'),
('Maring�', 'PR')

INSERT INTO Endereco (CidadeId, PessoaId, Logradouro, Numero, Cep, Bairro) VALUES
(1, 1, 'R Meyre Peretti Avelino', 493, '19000000', 'Parque S�o Matheus'),
(1, 2, 'R Cel. Albino', 493, '19000000', 'Jd S�o Matheus'),
(3, 3, 'R Neida de Paula', 493, '19000000', 'Vila Romana'),
(5, 4, 'R Catal�o', 493, '19000000', 'Centro'),
(5, 5, 'R Martin', 22, '19000000', 'Centro')

INSERT INTO Telefone (PessoaId, DDD, Numero) VALUES
(1, '18', '32229877'),
(2, '18', '32214455'),
(3, '18', '32227457'),
(4, '43', '985545589'),
(5, '43', '997555587')

INSERT INTO Titulo (CredorId, DevedorId, NumeroContrato, [Data], Valor) VALUES
(1, 1, '11155548', '20180110', 512.33),
(1, 1, '11135547', '20170101', 1512.33),
(1, 2, '11154546', '20190101', 2512.33),
(2, 1, '22255545', '20200101', 112.33),
(2, 4, '22265544', '20190501', 152.33)

INSERT INTO Parcelas (TituloId, Numero, Valor, Vencimento, Quitada, ParcelaResidualId) VALUES
(1, 5, 256.16, '20180101', 0, null),
(1, 6, 256.17, '20180201', 0, null),
(2, 10, 504, '20170101', 1, null),
(2, 11, 504, '20170201', 1, null),
(2, 12, 504, '20170301', 0, null),
(3, 9, 2512.33, '20190101', 1, null),
(4, 1, 112.33, '20200101', 0, null),
(4, 998, 2.33, '20200208', 0, 7),
(4, 998, 0.33, '20200308', 0, 7),
(5, 2, 152.33, '20190501', 0, null),
(5, 998, 1.15, '20190612', 0, 10),
(4, 998, 0.12, '20200308', 0, 7)

INSERT INTO Historico (Descricao, [Data]) VALUES
('Contato com o cliente sem sucesso', '20180110 09:00'),
('Pediu para filha dar recado', '20180110 16:00'),
('Pediu para ligar mais tarde', '20190101 11:00'),
('Vai pagar mes que vem', '20200101 12:00')

INSERT INTO HistoricoTitulo (HistoricoId, TituloId) VALUES
(1,1),
(1,2),
(2,1),
(2,2),
(3,3),
(4,4)

INSERT INTO Recebimento (TituloId, ValorTotal, DataPagamento) VALUES
(2, 504, '20170110 16:00'),
(2, 504, '20170210 16:00'),
(3, 2512.33, '20190110 16:00')

INSERT INTO RecebimentoParcelas (RecebimentoId, ParcelaId, ValorParcela, VencimentoParcela) VALUES
(1, 3, 504, '20170101'),
(2, 6, 2512.33, '20190101'),
(3, 4, 504, '20170201')
