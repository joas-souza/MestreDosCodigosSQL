CREATE TABLE Endereco (
	Id INT IDENTITY(1,1),
	Logradouro VARCHAR(150) NOT NULL,
	Numero INT NOT NULL,
	Cep VARCHAR(10) NULL,
	Bairro VARCHAR(100) NOT NULL,
	Cidade VARCHAR(100) NULL,
	Estado VARCHAR(2) NULL,
	Complemento VARCHAR(250) NULL
	CONSTRAINT PK_Endereco PRIMARY KEY (Id))
GO

CREATE TABLE Cliente (
	Id INT IDENTITY(1,1),
	EnderecoId INT NOT NULL,
	Nome VARCHAR(255) NOT NULL,
	Email VARCHAR(50) NULL,
	Telefone VARCHAR(15) NULL
	CONSTRAINT PK_Cliente PRIMARY KEY (Id), 
	CONSTRAINT FK_Cliente_EnderecoId FOREIGN KEY (EnderecoId) REFERENCES Endereco(Id))
GO
CREATE NONCLUSTERED INDEX IX_Cliente_EnderecoId ON Cliente (EnderecoId)
GO

CREATE TABLE Fornecedor (
	Id INT IDENTITY(1,1),
	EnderecoId INT NOT NULL,
	Nome VARCHAR(255) NOT NULL,
	Cnpj VARCHAR(20) NOT NULL,
	Telefone VARCHAR(15) NOT NULL
	CONSTRAINT PK_Fornecedor PRIMARY KEY (Id), 
	CONSTRAINT FK_Fornecedor_EnderecoId FOREIGN KEY (EnderecoId) REFERENCES Endereco(Id))
GO
CREATE NONCLUSTERED INDEX IX_Fornecedor_EnderecoId ON Fornecedor (EnderecoId)
GO

CREATE TABLE Funcionario (
    Id                   INT IDENTITY(1,1),
    EnderecoId           INT NOT NULL,
    Nome                 VARCHAR(255) NOT NULL,
    Identificacao        VARCHAR(50) NOT NULL,
    Telefone             VARCHAR(15) NOT NULL
    CONSTRAINT PK_Funcionario PRIMARY KEY (Id), 
    CONSTRAINT FK_Funcionario_EnderecoId FOREIGN KEY (EnderecoId) REFERENCES Endereco(Id))
GO
CREATE NONCLUSTERED INDEX IX_Funcionario_EnderecoId ON Funcionario (EnderecoId)
GO

CREATE TABLE Usuario (
    Id INT IDENTITY(1,1),
    EnderecoId INT NOT NULL,
    Nome VARCHAR(255) NOT NULL,
    Email VARCHAR(50) NULL
    CONSTRAINT PK_Usuario PRIMARY KEY (Id), 
    CONSTRAINT FK_Usuario_EnderecoId FOREIGN KEY (EnderecoId) REFERENCES Endereco(Id))
GO
CREATE NONCLUSTERED INDEX IX_Usuario_EnderecoId ON Usuario (EnderecoId)
GO

